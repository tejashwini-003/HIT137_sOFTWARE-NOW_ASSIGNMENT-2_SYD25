def encrypt_text(shift1, shift2):
    
    try:
        with open("raw_text.txt", "r") as file:
            text = file.read()
    except FileNotFoundError:
        print("Error: 'raw_text.txt' not found. Please ensure the file exists.")
        return

    encrypted = ""
    for ch in text:
        if 'a' <= ch <= 'z':
            pos = ord(ch) - ord('a')
            pos = (pos + shift1) % 26
            encrypted += chr(pos + ord('a'))
        elif 'A' <= ch <= 'Z':
            pos = ord(ch) - ord('A')
            pos = (pos + shift2) % 26
            encrypted += chr(pos + ord('A'))
        else:
            encrypted += ch

    with open("encrypted_text.txt", "w") as file:
        file.write(encrypted)
    print("Encryption completed. Check 'encrypted_text.txt'.")

def decrypt_text(shift1, shift2):
    """
    Decrypts the content of 'encrypted_text.txt' using a Caesar cipher:
    - Lowercase letters: Shift backward by shift1 positions.
    - Uppercase letters: Shift backward by shift2 positions.
    - Other characters: Remain unchanged.
    Writes the decrypted text to 'decrypted_text.txt'.
    """
    try:
        with open("encrypted_text.txt", "r") as file:
            text = file.read()
    except FileNotFoundError:
        print("Error: 'encrypted_text.txt' not found. Run encryption first.")
        return

    decrypted = ""
    for ch in text:
        if 'a' <= ch <= 'z':
            pos = ord(ch) - ord('a')
            pos = (pos - shift1) % 26
            decrypted += chr(pos + ord('a'))
        elif 'A' <= ch <= 'Z':
            pos = ord(ch) - ord('A')
            pos = (pos - shift2) % 26
            decrypted += chr(pos + ord('A'))
        else:
            decrypted += ch

    with open("decrypted_text.txt", "w") as file:
        file.write(decrypted)
    print("Decryption completed. Check 'decrypted_text.txt'.")

def verify_decryption():
    
    try:
        with open("raw_text.txt", "r") as file1:
            original = file1.read()
        with open("decrypted_text.txt", "r") as file2:
            decrypted = file2.read()
    except FileNotFoundError:
        print("Error: Required files not found. Run encryption and decryption first.")
        return

    if original == decrypted:
        print("Decryption successful. Files match.")
    else:
        print("Decryption failed. Files do not match.")

def main():
   
    try:
        shift1 = int(input("Enter shift1: "))
        shift2 = int(input("Enter shift2: "))
    except ValueError:
        print("Error: Shifts must be integers.")
        return

    encrypt_text(shift1, shift2)
    decrypt_text(shift1, shift2)
    verify_decryption()

if __name__ == "__main__":
    main()